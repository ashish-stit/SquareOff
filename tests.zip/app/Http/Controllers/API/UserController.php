<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use App\User; 
use Illuminate\Support\Facades\Auth; 
use Validator;
use Twilio\Rest\Client;
use Twilio\Jwt\ClientToken;
class UserController extends Controller 
{
public $successStatus = 200;
/** 
     * login api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function login(){ 
        if(Auth::attempt(['email' => request('email'), 'password' => request('password')])){ 
            $user = Auth::user(); 
            $success['token'] =  $user->createToken('MyApp')-> accessToken; 
            return response()->json(['success' => $success], $this-> successStatus); 
        } 
        else{ 
            return response()->json(['error'=>'Unauthorised'], 401); 
        } 
    }
/** 
     * Register api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function register(Request $request) 
    { 
    	
        $validator = Validator::make($request->all(), [ 
            'name' => 'required', 
            'email' => 'required|email|unique:users', 
            'password' => 'required', 
            'c_password' => 'required|same:password', 
        ]);
     if ($validator->fails()) { 
            return response()->json(['error'=>$validator->errors()], 401);            
        }
        try
        {
         $id=$request->id;
         $name=$request->name;
         $password=bcrypt($request->password);
         $email=$request->email;
         $age=$request->age;
         $city=$request->city;
         $country=$request->country;
         $state=$request->state;
         $dob=$request->dob;
         $area=$request->area; 
         $user=User::where('id',$id)->first();
         $user->name=$name;
         $user->password=$password;
         $user->email=$email; 
         $user->age=$age;
         $user->city=$city;
         $user->country=$country;
         $user->state=$state;
         $user->dob=$dob;
         $user->area=$area;
         $success['token'] =  $user->createToken('MyApp')-> accessToken; 
         $success['name'] =  $user->name;
        if($user->save())
        {
        return response()->json(['success'=>$success], $this-> successStatus); 
        } 
        else{ 
            return response()->json(['error'=>'Unauthorised'], 401); 
        } 
    }
     catch (Exception $e)
        {
            echo "Something wrong";
        }
    }
    public function sendotp(Request $request)
    {
        try{
        $mobile_no=$request->mobile_no;
        $accountSid = config('app.twilio')['TWILIO_ACCOUNT_SID'];
        $authToken  = config('app.twilio')['TWILIO_AUTH_TOKEN'];
        $appSid     = config('app.twilio')['TWILIO_APP_SID'];
        $client = new Client($accountSid, $authToken);
        $otp = mt_rand(1000,9999);
        $message=$client->messages->create($mobile_no,array('from' => '+1 830 243 6586', 'body' => $otp,));
        if($message)
        {
           $userdata=new User;
           $userdata->mobile_no=$mobile_no;
           $userdata->otp=$otp;
           if($userdata->save())
           {
                   $success['mobile_no']=$userdata->mobile_no;
                   $success['otp']=$userdata->otp;
                   $success['id']=$userdata->id;
                   $success['message']="Otp send successfully";
                   return response()->json(['success'=>$success], $this-> successStatus);
           }
        }
      }
      catch (Exception $e)
        {
            echo "Something wrong";
        }
         
    }
    public function verifyOtp(Request $request)
    {
        try
        {
           $id=$request->id;
           $mobile_no=$request->mobile_no;
           $otp=$request->otp;
           $verify_data=User::where('id',$id)->first();
           if($verify_data->verified == "1" && $verify_data->otp == $otp)
           {
                   $success['message']="Mobile number allready verified";
                   $success['id']=$id;
                   return response()->json(['success'=>$success], $this-> successStatus);
           }
           else if($verify_data->id == $id && $verify_data->otp == $otp)
           {
                   $verify_data->verified="1";
                   if($verify_data->save())
                   {
                   $success['message']="Mobile number verified successfully";
                   $success['id']=$id;
                   return response()->json(['success'=>$success], $this-> successStatus);
               }
           }
           else{ 
            return response()->json(['error'=>'Unauthorised'], 401); 
        } 
          
        }
        catch (Exception $e)
        {
            echo "Something wrong";
        }
    }
  
}